

srvc = {}

srvc.isAndroid = function()

    print("srvc.isAndroid "..tostring(isAndroid).."")

    return (isAndroid == 1)

end
